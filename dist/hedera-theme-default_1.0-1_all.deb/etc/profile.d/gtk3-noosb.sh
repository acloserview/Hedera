#/bin/sh
export GTK_OVERLAY_SCROLLING=0
